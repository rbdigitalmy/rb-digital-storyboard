# RB Digital Storyboard Suite

Plugin Skills Only yang menggabungkan 19 workflow Custom GPT milik RB Digital. Pakej ini tidak mempunyai MCP, app connector, API key atau dependency luaran.

## Skill yang disertakan

- Cartoon Storyboard
- Character Sheet
- Kawaii Image
- OOTD
- Poster
- Real Human
- Real Product
- Realtoon
- Storyboard Anthropomorphic
- Storyboard ASMR
- Storyboard Chibi
- Storyboard Grafix
- Storyboard Pix
- Storyboard Podcast
- Storyboard POV Hand
- Storyboard Stop Motion
- Storyboard Talking Head
- Storyboard Universal
- Thumbnail

Setiap workflow berada dalam folder skill tersendiri supaya Codex boleh memilih arahan yang tepat berdasarkan permintaan pengguna.

## Status

- Version: 0.1.0
- Author: Najib
- Format: Agent Plugins 1.0
- Visibility selepas dicipta: Private
- MCP: Tiada

## Penggunaan dan perkongsian

Keseluruhan folder ini ialah satu plugin mudah alih. Ia boleh dizip untuk import sebagai plugin peribadi atau disimpan dalam repositori Git untuk dikongsi dengan pasukan. Mengezip atau berkongsi sumber ini tidak menerbitkannya ke Plugins Directory.

Sebelum versi pertama dimuat naik, semak nota kandungan yang dibekalkan bersama pakej. Selepas sebarang perubahan, naikkan nombor versi dalam `plugin.json`.
